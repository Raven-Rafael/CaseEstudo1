﻿
namespace CaseEstudo1.Domain
{ 
    public enum TamanhoBebidaEnum
    {
        Lata,
        Garrafa600ml,
        Garrafa2L
    }
}