﻿namespace CaseEstudo1.DTOs
{
    public class BordaPrecoDTO
    {
        public string Nome { get; set; } = string.Empty;
        public decimal Preco { get; set; }
    }
}
