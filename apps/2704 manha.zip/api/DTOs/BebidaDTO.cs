﻿
    namespace CaseEstudo1.DTOs
    {
        public class BebidaDTO
        {
            public int Id { get; set; }
            public string Nome { get; set; } = string.Empty;
            public bool Disponivel { get; set; }
        }
    }
