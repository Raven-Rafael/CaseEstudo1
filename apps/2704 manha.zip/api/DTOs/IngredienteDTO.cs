﻿namespace CaseEstudo1.DTOs
{
    public class IngredienteDTO
    {
        public int Id { get; set; }
        public string Nome { get; set; } = string.Empty;
    }
}
