﻿using System;

namespace CaseEstudo1.DTOs
{
    public class PedidoResponseDTO
    {
        public int Id { get; set; }

        public DateTime DataPedido { get; set; }

        public string NomeCliente { get; set; } = string.Empty;

        public string? TelefoneCliente { get; set; }

        public string NomePizza { get; set; } = string.Empty;

        public decimal PrecoPizza { get; set; }

        public string? NomeBebida { get; set; }

        public decimal? PrecoBebida { get; set; }

        public decimal PrecoTotal { get; set; }

        public string Status { get; set; } = "Em processamento";
    }
}
