﻿using CaseEstudo1.Architecture.Interfaces;
using CaseEstudo1.DTOs;
using Microsoft.AspNetCore.Mvc;

namespace CaseEstudo1.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class PedidoController : ControllerBase
    {
        private readonly IPedidoService _pedidoService;

        public PedidoController(IPedidoService pedidoService)
        {
            _pedidoService = pedidoService;
        }

        [HttpPost]
        public async Task<ActionResult<PedidoResponseDTO>> CriarPedido([FromBody] PedidoDTO dto)
        {
            var pedido = await _pedidoService.CriarPedidoAsync(dto);
            return CreatedAtAction(nameof(BuscarPorId), new { id = pedido.Id }, pedido);
        }

        [HttpGet]
        public async Task<ActionResult<IEnumerable<PedidoResponseDTO>>> ListarPedidos()
        {
            var pedidos = await _pedidoService.ListarPedidosAsync();
            return Ok(pedidos);
        }

        [HttpGet("{id}")]
        public async Task<ActionResult<PedidoResponseDTO>> BuscarPorId(int id)
        {
            var pedido = await _pedidoService.BuscarPedidoPorIdAsync(id);
            if (pedido == null)
                return NotFound();

            return Ok(pedido);
        }
    }
}
