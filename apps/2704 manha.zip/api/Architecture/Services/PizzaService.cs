﻿using System.Collections.Generic;
using System.Threading.Tasks;
using CaseEstudo1.Architecture.Interfaces;
using CaseEstudo1.Data;
using CaseEstudo1.Domain;
using CaseEstudo1.DTOs;
using Microsoft.EntityFrameworkCore;

namespace CaseEstudo1.Architecture.Services
{
    public class PizzaService : IPizzaService
    {
        private readonly AppDbContext _context;

        public PizzaService(AppDbContext context)
        {
            _context = context;
        }

        public async Task<IEnumerable<Pizza>> GetAllAsync()
        {
            return await _context.Pizzas.ToListAsync();
        }

        public async Task<Pizza?> GetByIdAsync(int id)
        {
            return await _context.Pizzas.FindAsync(id);
        }

        public async Task<Pizza> CreateAsync(CreatePizzaDTO dto)
        {
            var pizza = new Pizza
            {
                Nome = dto.Nome,
                Descricao = dto.Descricao,
                Tamanho = dto.Tamanho,
                Disponivel = dto.Disponivel,
                Preco = dto.Preco, 
                NomeBebida = dto.NomeBebida,
                PrecoBebida = dto.PrecoBebida
            };


            if (!string.IsNullOrEmpty(dto.NomeBebida) && dto.PrecoBebida > 0)
            {
                pizza.Preco += dto.PrecoBebida;
            }

            _context.Pizzas.Add(pizza);
            await _context.SaveChangesAsync();
            return pizza;
        }

        public async Task<Pizza?> UpdateAsync(int id, UpdatePizzaDTO dto)
        {
            var existingPizza = await _context.Pizzas.FindAsync(id);
            if (existingPizza == null) return null;

            existingPizza.Nome = dto.Nome;
            existingPizza.Descricao = dto.Descricao;
            existingPizza.Tamanho = dto.Tamanho;
            existingPizza.Disponivel = dto.Disponivel;
            existingPizza.Preco = dto.Preco;
            existingPizza.NomeBebida = dto.NomeBebida;
            existingPizza.PrecoBebida = dto.PrecoBebida;


            if (!string.IsNullOrEmpty(dto.NomeBebida) && dto.PrecoBebida > 0)
            {
                existingPizza.Preco = dto.Preco + dto.PrecoBebida;
            }

            await _context.SaveChangesAsync();
            return existingPizza;
        }

        public async Task<bool> DeleteAsync(int id)
        {
            var pizza = await _context.Pizzas.FindAsync(id);
            if (pizza == null) return false;

            _context.Pizzas.Remove(pizza);
            await _context.SaveChangesAsync();
            return true;
        }
    }
}
