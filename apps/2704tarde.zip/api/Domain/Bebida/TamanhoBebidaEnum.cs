﻿namespace CaseEstudo1.Domain
{
    public enum TamanhoBebidaEnum
    {
        Lata,
        Caixinha,
        Garrafa500ml,
        Garrafa600ml,
        Caixa1L,
        Garrafa2L
    }
}
