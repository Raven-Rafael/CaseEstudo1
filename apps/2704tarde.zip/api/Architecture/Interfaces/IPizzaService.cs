﻿using System.Collections.Generic;
using System.Threading.Tasks;
using CaseEstudo1.DTOs;

namespace CaseEstudo1.Architecture.Interfaces
{
    public interface IPizzaService
    {
        Task<IEnumerable<PizzaResponseDTO>> GetAllAsync();
        Task<PizzaResponseDTO?> GetByIdAsync(int id);
        Task<PizzaResponseDTO> CreatePizzaAsync(CreatePizzaDTO dto);
        Task<PizzaResponseDTO?> UpdatePizzaAsync(int id, UpdatePizzaDTO dto);
        Task<bool> DeleteAsync(int id);
    }
}
